#ifndef UTILS_H_
#define UTILS_H_

void print_bar(int size, float progress, int strike_zone);

#endif